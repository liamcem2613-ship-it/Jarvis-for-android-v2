# JARVIS Android

A native Kotlin + Jetpack Compose Android assistant starter with:
- Chat against an OpenAI-compatible Chat Completions endpoint
- Encrypted local API-key preferences (AndroidX Security Crypto)
- Android speech recognition for voice input
- Android TextToSpeech for spoken responses
- Basic local conversation transcript and simple prompt-history persistence
- Dark JARVIS-inspired interface

## Build an APK
1. Install Android Studio (recent stable version) and Android SDK 35.
2. Open this folder in Android Studio.
3. Let Gradle sync and download dependencies.
4. Connect an Android device or start an emulator.
5. Use **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. Android Studio reports the generated APK location (normally `app/build/outputs/apk/debug/app-debug.apk`).

## Configure
Open JARVIS > Settings and enter a newly generated API key and an OpenAI-compatible
`/v1/chat/completions` endpoint. The default model is `gpt-4o-mini`; edit
`MainActivity.kt` if your provider uses a different model or request format.

No API key is included in this project. Do not put secrets in source control.
A mobile client containing a provider key is suitable for personal testing, but a
production app should proxy requests through a secured backend so the key is never
distributed in the APK.

## Current scope and limitations
This is a working starter app, not the entire desktop-agent specification:
- Android speech recognition is tap-to-talk; no always-on wake-word service.
- Memory is a small local prompt-history string, not semantic searchable memory.
- It does not run arbitrary shell commands, silently monitor the device, or control
  other apps. Those capabilities require explicit Android permissions and separate
  reviewed modules.
- Web research and file tools are not yet connected.
- The AI request currently uses the OpenAI-compatible Chat Completions format.

## Security
The two API credentials previously pasted into chat should be revoked and replaced.
Never reuse them. Configure a fresh key locally in the app.
